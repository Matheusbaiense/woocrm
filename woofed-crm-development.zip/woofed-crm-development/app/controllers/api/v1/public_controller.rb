class Api::V1::PublicController < ActionController::API
end
