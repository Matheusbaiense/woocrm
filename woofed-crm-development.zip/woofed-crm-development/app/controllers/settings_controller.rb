class SettingsController < InternalController

  def index
  end
end