class Accounts::WelcomeController < InternalController
  def index

  end
end