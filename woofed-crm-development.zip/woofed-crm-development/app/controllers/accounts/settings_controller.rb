class Accounts::SettingsController < InternalController
  def index
  end
end