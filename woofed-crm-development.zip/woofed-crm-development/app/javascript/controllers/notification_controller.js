import Notification from 'stimulus-notification'

export default class extends Notification {
  connect() {
    super.connect()
  }
}
