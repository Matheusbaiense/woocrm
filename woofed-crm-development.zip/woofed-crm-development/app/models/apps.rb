module Apps
  def self.table_name_prefix
    'apps_'
  end
end
