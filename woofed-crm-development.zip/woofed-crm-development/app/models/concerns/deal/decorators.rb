module Deal::Decorators
end
